﻿//using BloodBankingManagment.Model;
//using Microsoft.EntityFrameworkCore;

//namespace BloodBankingManagment.Data
//{
//    public class AppDbContext : DbContext
//    {
//        public AppDbContext(DbContextOptions options) : base(options)
//        {
//        }
//        public DbSet<Admin> admin { get; set; }

//    }
//}
