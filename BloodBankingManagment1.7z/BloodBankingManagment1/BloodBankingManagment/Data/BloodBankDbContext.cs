﻿using BloodBankingManagment.Model;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Data
{
    public class BloodBankDbContext : DbContext
    {
        public BloodBankDbContext(DbContextOptions<BloodBankDbContext> options) : base(options)
        {

        }

        public DbSet<Donor> donor { get; set; }

        public DbSet<BloodInventory> bloodInventory { get; set; }

        public DbSet<Order> orders { get; set; }

        public DbSet<Admin> admin { get; set; }



    }
}