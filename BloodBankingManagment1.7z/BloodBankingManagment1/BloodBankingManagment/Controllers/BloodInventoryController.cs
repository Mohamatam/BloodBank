﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using BloodBankingManagment.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BloodInventoryController : ControllerBase
    {
        private IBloodInventoryRepository _bloodInventoryRepository;
        private BloodBankDbContext _dbContext;

        public BloodInventoryController(IBloodInventoryRepository bloodInventoryRepository, BloodBankDbContext dbContext)
        {
            _bloodInventoryRepository = bloodInventoryRepository;
            _dbContext = dbContext;
        }

        //[Authorize(Roles = "Admin")]
        [HttpGet]
        [Route("GetDonor")]
        public async Task<IEnumerable<BloodInventory>> GetDonor()
        {
            return await _bloodInventoryRepository.GetBI();
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        public async Task<ActionResult<BloodInventory>> GetUsers(int id)
        {
            return await _bloodInventoryRepository.GetBIById(id);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        [Route("CreateBloodInventory")]
        public async Task<ActionResult<Donor>> CreateBloodInventory([FromBody] BloodInventory bloodInventory)
        {
            try
            {
                var newUser = await _bloodInventoryRepository.Create(bloodInventory);
                return CreatedAtAction(nameof(CreateBloodInventory), new { id = newUser }, newUser);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred. Please contact support.", ex);
            }
        }

        [HttpPost("updateQuantity")]
        public async Task<IActionResult> UpdateQuantity([FromBody] BloodInventory request)
        {
           
            var item = await _dbContext.bloodInventory.FirstOrDefaultAsync(i => i.BloodGroup == request.BloodGroup);

           
            if (item == null)
            {
                return NotFound(new { success = false, message = "Blood group not found." });
            }

            if (item.Quantity < request.Quantity)
            {
                return BadRequest(new { success = false, message = "Insufficient quantity." });
            }

            item.Quantity -= request.Quantity;

            await _dbContext.SaveChangesAsync();

            return Ok(new { success = true, message = "Quantity updated successfully." });
        }


    }

    }

