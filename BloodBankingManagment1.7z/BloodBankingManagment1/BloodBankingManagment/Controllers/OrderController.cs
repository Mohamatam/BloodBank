﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using BloodBankingManagment.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly BloodBankDbContext DbContext;
      
        public OrderController(IOrderRepository orderRepository, BloodBankDbContext DbContext)
        {
            this._orderRepository = orderRepository;
            this.DbContext = DbContext;
        }

        [HttpGet]
        [Route("GetDonor")]
        public async Task<IEnumerable<Order>> GetOrder()
        {
            return await _orderRepository.GetOrderDetails();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Order>> GetOrderDetailsById(int id)
        {
            return await _orderRepository.GetOrderById(id);
        }


        [HttpPost]
        [Route("CreateOrder")]
        public async Task<ActionResult<Order>> CreateOrder([FromBody] Order ord)
        {
            try
            {
                var newUser = await _orderRepository.CreateOrder(ord);
                return CreatedAtAction(nameof(CreateOrder), new { id = newUser }, newUser);
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred. Please contact support.", ex);
            }
        }

        [HttpPut]
        [Route("UpdateDonor/{id}")]
        public async Task<ActionResult> UpdateOrder(int id, [FromBody] Order ord)
        {
            if (id != ord.OrderId)
            {
                return BadRequest();
            }
            try
            {
                await _orderRepository.UpdateOrder(ord);
                return NoContent();
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred.Please contact support.", ex);
            }
        }

        [HttpPost("PlaceOrders")]
        public async Task<IActionResult> PlaceOrders([FromBody] Order request)

        {
            if (request == null)
            {
                return BadRequest("Invalid order request.");
            }

            // Call the service to place the order
            var result = await _orderRepository.PlaceOrderAsync(
                request.BloodGroup,
                request.Quantity,
                request.CustomerName,
                request.CustomerMobile,
                request.CustomerAddress
            );

            if (result == "Order placed successfully.")
            {
                return Ok(new { message = result });
            }
            else
            {
                return BadRequest(new { message = result });
            }
        }
    }
}
      
    
