﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using BloodBankingManagment.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminRepository _adminRepository;
        private readonly BloodBankDbContext _dbContext;
        private readonly JwtService _jwtService;
        private readonly IConfiguration _config;

        public AdminController(IAdminRepository adminRepository, BloodBankDbContext dbContext, JwtService jwtService, IConfiguration config)
        {
            _adminRepository = adminRepository;
            _dbContext = dbContext;
            _jwtService = jwtService;
            _config = config;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("CreateAdmin")]
        public async Task<ActionResult<Admin>> CreateAdmin([FromBody] Admin admin)
        {
            try
            {
                // Check if the email already exists
                bool emailExists = await _dbContext.admin.AnyAsync(u => u.AdminEmail == admin.AdminEmail);
                if (emailExists)
                {
                    return Conflict(new { message = "An admin with this email already exists." });
                }

                // Create new admin
                var newAdmin = await _adminRepository.Create(admin);
                return CreatedAtAction(nameof(CreateAdmin), new { id = newAdmin.AdminId }, new { message = "Admin account created successfully", admin = newAdmin });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = "An unexpected error occurred. Please contact support.", error = ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("AdminLogin")]
        public IActionResult AdminLogin([FromBody] AdminLogin adminLogin)
        {
            var adminAvailable = _dbContext.admin
                .FirstOrDefault(d => d.AdminEmail == adminLogin.AdminEmail && d.AdminPassword == adminLogin.AdminPassword);

            if (adminAvailable != null)
            {
                var token = _jwtService.GenerateToken(
                    adminAvailable.AdminId.ToString(),
                    adminAvailable.AdminName,
                    adminAvailable.AdminEmail,
                    adminAvailable.Mobile,
                    adminAvailable.Role

                );
                return Ok(new { status = "Success", token }); 
            }

            return Unauthorized(new { status = "Failure", message = "Invalid credentials" }); 
        }
    }
}
