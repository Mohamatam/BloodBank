﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using BloodBankingManagment.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Principal;

namespace BloodBankingManagment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    
    public class DonorController : ControllerBase
    {
        private IDonorRepository _donorRepository;
        private BloodBankDbContext _dbContext;
        private readonly JwtService _jwtService;
        private readonly IConfiguration _config;

        
        public DonorController(IDonorRepository donorRepository, BloodBankDbContext dbContext, JwtService jwtService, IConfiguration config)
        {
            _donorRepository = donorRepository;
            _dbContext = dbContext;
            _jwtService = jwtService;
            _config = config;
        }

       


        [AllowAnonymous]
        [HttpPost]
        [Route("CreateDonor")]
public async Task<ActionResult<Donor>> CreateDonor([FromBody]Donor donor) 
{
    try
    {
        bool emailExists = _dbContext.donor.Any(u => u.DonorEmail == donor.DonorEmail);
        if (emailExists)
        {
            //Console.WriteLine("Already Exists");
            return Conflict(new { message = "A donor with this email already exists." });
        }
        var newUser = await _donorRepository.Create(donor);
        return CreatedAtAction(nameof(CreateDonor), new { id = newUser }, new { message = "Account Created Successfully" });
    }
    catch (Exception ex)
    {
        throw new Exception("An unexpected error occurred. Please contact support.", ex);
    }
}
        
       

        [AllowAnonymous]
        [HttpPost]
        [Route("DonorLogin")]
        public IActionResult DonorLogin(DonorLogin donorLogin)
        {
            var donorAvailable = _dbContext.donor.Where(d => d.DonorEmail == donorLogin.DonorEmail && d.DonorPassword == donorLogin.DonorPassword).FirstOrDefault();
            if (donorAvailable != null)
            {
                return Ok("Success");
            }
            return Ok("Failure");
        }
    }
    }
