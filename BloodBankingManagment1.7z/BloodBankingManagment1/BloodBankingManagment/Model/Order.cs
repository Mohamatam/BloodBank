﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BloodBankingManagment.Model
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; } 
        [Required, ForeignKey("BloodInventory")]
        public int BloodInventoryId { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public string OrderStatus { get; set; }
        [Required]
        public string CustomerName { get; set; }
        [Required, StringLength(10)]
        public string CustomerMobile { get; set; }
        [Required]
        public string CustomerAddress { get; set; }

        public BloodInventory BloodInventory { get; set; } // Navigation Property
        public string BloodGroup => BloodInventory?.BloodGroup;
    }
}
