﻿namespace BloodBankingManagment.Model
{
    public class AdminLogin
    {
        public string AdminEmail { get; set; }

        public string AdminPassword { get; set; }


    }
}
