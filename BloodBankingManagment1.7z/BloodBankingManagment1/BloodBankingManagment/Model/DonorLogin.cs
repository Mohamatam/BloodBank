﻿namespace BloodBankingManagment.Model
{
    public class DonorLogin
    {
        public string DonorEmail { get; set; }
        public string DonorPassword { get; set; }

    }
}
