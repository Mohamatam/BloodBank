﻿using System.ComponentModel.DataAnnotations;

namespace BloodBankingManagment.Model
{
    public class Donor
    {
        [Required]
        [Key]
        public int DonorId { get; set; } 
        [Required]
        public string DonorName { get; set; }
        [Required, DataType(DataType.EmailAddress)]
        public string DonorEmail { get; set; }
        [Required, StringLength(10)]
        public string Mobile { get; set; }
        [Required]
        public string Address { get; set; }

        [Required, DataType(DataType.Password), Compare("DonorConfPass")]
        public string DonorPassword { get; set; }

        [Required, DataType(DataType.Password)]
        public string DonorConfPass { get; set; }

    }
}
