﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BloodBankingManagment.Model
{
    public class JwtService
    {

        public String SecretKey { get; set; }
        public int TokenDuration { get; set; }

        private readonly IConfiguration _config;

        public JwtService(IConfiguration config)
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config), "Configuration cannot be null.");
            }
           
            this.SecretKey = config.GetSection("jwtConfig:key")?.Value
            ?? throw new ArgumentNullException("jwtConfig:key", "JWT key is missing in configuration.");
            this.TokenDuration = Int32.Parse(config.GetSection("jwtConfig").GetSection("Duration")?.Value);
        }

        public string GenerateToken(String AdminId, String AdminName, String AdminEmail, String Mobile, string role)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(this.SecretKey));
            var Signature = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var payLoad = new[]
            {
            new Claim("AdminId", AdminId),
            new Claim("AdminName", AdminName),
            new Claim("AdminEmail", AdminEmail),
            new Claim("Mobile", Mobile),
            new Claim(ClaimTypes.Role, role) // Add role claim

        };

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: payLoad,
                expires: DateTime.Now.AddMinutes(TokenDuration),
                signingCredentials: Signature
                );

            return new JwtSecurityTokenHandler().WriteToken(jwtToken);
        }

        public string GenerateTokenDonor(String DonorId, String DonorName, String DonorEmail, String Mobile)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(this.SecretKey));
            var Signature = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var payLoad = new[]
            {
            new Claim("DonorId", DonorId),
            new Claim("DonorName", DonorName),
            new Claim("DonorEmail", DonorEmail),
            new Claim("Mobile", Mobile),

        };

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: payLoad,
                expires: DateTime.Now.AddMinutes(TokenDuration),
                signingCredentials: Signature
                );

            return new JwtSecurityTokenHandler().WriteToken(jwtToken);
        }
    }
}