﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BloodBankingManagment.Model
{
    public class BloodInventory
    {
        [Key]
        public int BloodInventoryId { get; set; } 
        [Required]
        public string BloodGroup { get; set; } 
        [Required]
        public int Quantity { get; set; } 
        
        [Required, ForeignKey("Donor")]
        public int DonorId { get; set; } 

    }
}
