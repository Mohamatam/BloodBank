﻿using System.ComponentModel.DataAnnotations;

namespace BloodBankingManagment.Model
{
    public class Admin
    {
        [Required]
        [Key]
        public int AdminId { get; set; }
        [Required]
        public string AdminName { get; set; }
        [Required, DataType(DataType.EmailAddress)]
        public string AdminEmail { get; set; }
        [Required, StringLength(10)]
        public string Mobile { get; set; }
        [Required]
        public string Address { get; set; }

        [Required, DataType(DataType.Password), Compare("AdminConfPass")]
        public string AdminPassword { get; set; }

        [Required, DataType(DataType.Password)]
        public string AdminConfPass { get; set; }
        [Required]
        public string Role { get; set; } // e.g., "Admin"
    }
}
