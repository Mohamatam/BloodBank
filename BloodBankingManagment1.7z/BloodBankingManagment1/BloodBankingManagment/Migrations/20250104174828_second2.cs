﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BloodBankingManagment.Migrations
{
    public partial class second2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AlertStatus",
                table: "bloodInventory");

            migrationBuilder.AddColumn<string>(
                name: "OrderStatus",
                table: "orders",
                type: "text",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OrderStatus",
                table: "orders");

            migrationBuilder.AddColumn<string>(
                name: "AlertStatus",
                table: "bloodInventory",
                type: "text",
                nullable: false,
                defaultValue: "");
        }
    }
}
