﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BloodBankingManagment.Migrations
{
    public partial class second : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CustomerAddress",
                table: "orders",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CustomerMobile",
                table: "orders",
                type: "character varying(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CustomerName",
                table: "orders",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_orders_BloodInventoryId",
                table: "orders",
                column: "BloodInventoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_orders_bloodInventory_BloodInventoryId",
                table: "orders",
                column: "BloodInventoryId",
                principalTable: "bloodInventory",
                principalColumn: "BloodInventoryId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_orders_bloodInventory_BloodInventoryId",
                table: "orders");

            migrationBuilder.DropIndex(
                name: "IX_orders_BloodInventoryId",
                table: "orders");

            migrationBuilder.DropColumn(
                name: "CustomerAddress",
                table: "orders");

            migrationBuilder.DropColumn(
                name: "CustomerMobile",
                table: "orders");

            migrationBuilder.DropColumn(
                name: "CustomerName",
                table: "orders");
        }
    }
}
