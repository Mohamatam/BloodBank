﻿using BloodBankingManagment.Model;

namespace BloodBankingManagment.Repository
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetOrderDetails();
        Task<Order> GetOrderById(int id);
        Task<Order> CreateOrder(Order ord);
        Task UpdateOrder(Order ord);

        Task<string> PlaceOrderAsync(string bloodGroup, int quantity, string customerName, string customerMobile, string customerAddress);
    }
}
