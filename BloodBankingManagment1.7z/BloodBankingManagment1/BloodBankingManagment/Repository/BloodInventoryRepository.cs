﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Repository
{
    public class BloodInventoryReposiroty : IBloodInventoryRepository
    {
        private readonly BloodBankDbContext _con;

        public BloodInventoryReposiroty(BloodBankDbContext con)
        {
            _con = con;
        }

        public async Task<IEnumerable<BloodInventory>> GetBI()
        {
            return await _con.bloodInventory.ToListAsync();
        }

        public async Task<BloodInventory> GetBIById(int id)
        {
            return await _con.bloodInventory.FindAsync(id);
        }

        public async Task<BloodInventory> Create(BloodInventory bloodInventory)
        {
            try
            {
                _con.bloodInventory.Add(bloodInventory);
                await _con.SaveChangesAsync();
                return bloodInventory;
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred. Please contact support.", ex);
            }

        }

       
            
             
    }
}

