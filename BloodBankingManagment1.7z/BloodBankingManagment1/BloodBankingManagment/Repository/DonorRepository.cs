﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Repository
{
    public class DonorRepository : IDonorRepository
    {
        private readonly BloodBankDbContext _con;

        public DonorRepository(BloodBankDbContext con)
        {
            _con = con;
        }

       

        public async Task<Donor> Create(Donor donor)
        {
            _con.donor.Add(donor);
            await _con.SaveChangesAsync();
            return donor;
        }

        }

      

    }

