﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;
using Microsoft.EntityFrameworkCore;

namespace BloodBankingManagment.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly BloodBankDbContext _con;

        public OrderRepository(BloodBankDbContext con)
        {
            _con=con;
            
        }
        public async Task<IEnumerable<Order>> GetOrderDetails()
        {
            return await _con.orders.ToListAsync();
        }
        public async Task<Order> GetOrderById(int id)
        {
            return await _con.orders.FindAsync(id);
        }

        public async Task<Order> CreateOrder(Order ord)
        {
            _con.orders.Add(ord);
            await _con.SaveChangesAsync();
            return ord;
        }

        public async Task UpdateOrder(Order ord)
        {
            try
            {
                _con.Entry(ord).State = EntityState.Modified;
                await _con.SaveChangesAsync();
               
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred. Please contact support.", ex);
            }
        }

        public async Task DeleteOrder(int id)
        {
            try
            {
                var donorToDelete = await _con.orders.FindAsync(id);
                _con.orders.Remove(donorToDelete);
                _con.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An unexpected error occurred. Please contact support.", ex);
            }
        }

        public async Task<string> PlaceOrderAsync(string bloodGroup, int quantity, string customerName, string customerMobile, string customerAddress)
        {
            // Check if there's any BloodInventory with the given blood group
            var bloodInventory = await _con.bloodInventory
                                              .FirstOrDefaultAsync(b => b.BloodGroup == bloodGroup);

            if (bloodInventory == null)
            {
                return "Blood type not found.";
            }

            // Check if the available quantity is enough
            if (bloodInventory.Quantity < quantity)
            {
                return "Out of stock. Not enough blood available.";
            }

            // Create a new Order if enough quantity is available
            var order = new Order
            {
                BloodInventoryId = bloodInventory.BloodInventoryId,
                Quantity = quantity,
                OrderStatus = "pending",
                CustomerName = customerName,
                CustomerMobile = customerMobile,
                CustomerAddress = customerAddress
            };


            // Reduce the quantity in the BloodInventory
            bloodInventory.Quantity -= quantity;

            // Add the order to the database
            _con.orders.Add(order);

            // Save changes to the database
            await _con.SaveChangesAsync();

            return "Order placed successfully.";
        }
       
    }
}
