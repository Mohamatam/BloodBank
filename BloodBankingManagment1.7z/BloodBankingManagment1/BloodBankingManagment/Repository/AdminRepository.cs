﻿using BloodBankingManagment.Data;
using BloodBankingManagment.Model;

namespace BloodBankingManagment.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly BloodBankDbContext _con;

        public AdminRepository(BloodBankDbContext con)
        {
            _con = con;
        }

        public async Task<Admin> Create(Admin admin)
        {
            _con.admin.Add(admin);
            await _con.SaveChangesAsync();
            return admin;
        }

    }
}

