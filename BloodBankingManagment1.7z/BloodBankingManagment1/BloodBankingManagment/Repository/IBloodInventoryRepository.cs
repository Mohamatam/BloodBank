﻿using BloodBankingManagment.Model;
using System.Threading.Tasks;

namespace BloodBankingManagment.Repository
{
    public interface IBloodInventoryRepository
    {
        Task<IEnumerable<BloodInventory>> GetBI();
        Task<BloodInventory> GetBIById(int id);
        Task<BloodInventory> Create(BloodInventory bloodInventory);
       
    }
}
