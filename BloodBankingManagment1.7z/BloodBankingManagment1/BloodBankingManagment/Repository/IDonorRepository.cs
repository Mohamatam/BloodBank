﻿using BloodBankingManagment.Model;
using System.Threading.Tasks;

namespace BloodBankingManagment.Repository
{
    public interface IDonorRepository
    {
        
        Task<Donor> Create(Donor donor);
       
    }
}
