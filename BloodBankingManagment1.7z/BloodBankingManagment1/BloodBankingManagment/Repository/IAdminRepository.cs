﻿using BloodBankingManagment.Model;

namespace BloodBankingManagment.Repository
{
    public interface IAdminRepository
    {
        Task<Admin> Create(Admin admin);

    }
}
